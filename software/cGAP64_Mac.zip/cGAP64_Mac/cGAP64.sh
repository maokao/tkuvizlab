#!/bin/sh
export JAVA_HOME=`/usr/libexec/java_home -v 1.8`
java -jar -Xmx50000m cGAP.jar